-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 20, 2018 at 07:59 PM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rsps`
--

-- --------------------------------------------------------

--
-- Table structure for table `characterlooks`
--

DROP TABLE IF EXISTS `characterlooks`;
CREATE TABLE IF NOT EXISTS `characterlooks` (
  `username` varchar(255) NOT NULL,
  `character-look` int(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `characters`
--

DROP TABLE IF EXISTS `characters`;
CREATE TABLE IF NOT EXISTS `characters` (
  `username` varchar(50) NOT NULL,
  `character-rights` varchar(255) NOT NULL,
  `character-rights-secondary` varchar(255) NOT NULL,
  `character-mac-address` varchar(255) NOT NULL,
  `character-ip-address` varchar(255) NOT NULL,
  `revert-option` varchar(255) NOT NULL,
  `mode` varchar(255) NOT NULL,
  `tutorial-stage` varchar(255) NOT NULL,
  `character-height` varchar(255) NOT NULL,
  `character-hp` varchar(255) NOT NULL,
  `play-time` varchar(255) NOT NULL,
  `last-clan` varchar(255) NOT NULL,
  `character-specRestore` varchar(255) NOT NULL,
  `character-posx` varchar(255) NOT NULL,
  `character-posy` varchar(255) NOT NULL,
  `bank-pin` varchar(255) NOT NULL,
  `bank-pin-cancellation` varchar(255) NOT NULL,
  `bank-pin-unlock-delay` varchar(255) NOT NULL,
  `placeholders` varchar(255) NOT NULL,
  `newStarter` varchar(255) NOT NULL,
  `bank-pin-cancellation-delay` varchar(255) NOT NULL,
  `dailyTaskDate` varchar(255) NOT NULL,
  `totalDailyDone` varchar(255) NOT NULL,
  `currentTask` varchar(255) NOT NULL,
  `completedDailyTask` varchar(255) NOT NULL,
  `playerChoice` varchar(255) NOT NULL,
  `dailyEnabled` varchar(255) NOT NULL,
  `show-drop-warning` varchar(255) NOT NULL,
  `hourly-box-toggle` varchar(255) NOT NULL,
  `fractured-crystal-toggle` varchar(255) NOT NULL,
  `accept-aid` varchar(255) NOT NULL,
  `did-you-know` varchar(255) NOT NULL,
  `lootvalue` varchar(255) NOT NULL,
  `raidPoints` varchar(255) NOT NULL,
  `maRound` varchar(255) NOT NULL,
  `raidCount` varchar(255) NOT NULL,
  `experience-counter` varchar(255) NOT NULL,
  `character-title-updated` varchar(255) NOT NULL,
  `removed-slayer-tasks` varchar(255) NOT NULL,
  `last-incentive` varchar(255) NOT NULL,
  `rfd-round` varchar(255) NOT NULL,
  `run-energy` varchar(255) NOT NULL,
  `character-historyItems` varchar(255) NOT NULL,
  `character-historyItemsN` varchar(255) NOT NULL,
  `character-historyPrice` varchar(255) NOT NULL,
  `lastLoginDate` varchar(255) NOT NULL,
  `has-npc` varchar(255) NOT NULL,
  `summonId` varchar(255) NOT NULL,
  `startPack` varchar(255) NOT NULL,
  `crystalDrop` varchar(255) NOT NULL,
  `setPin` varchar(255) NOT NULL,
  `slayer-helmet` varchar(255) NOT NULL,
  `slayer-imbued-helmet` varchar(255) NOT NULL,
  `bigger-boss-tasks` varchar(255) NOT NULL,
  `cerberus-route` varchar(255) NOT NULL,
  `superior-slayer` varchar(255) NOT NULL,
  `slayer-tasks-completed` varchar(255) NOT NULL,
  `claimedReward` varchar(255) NOT NULL,
  `dragonfire-shield-charge` varchar(255) NOT NULL,
  `rfd-gloves` varchar(255) NOT NULL,
  `wave-id` varchar(255) NOT NULL,
  `wave-type` varchar(255) NOT NULL,
  `wave-info` varchar(255) NOT NULL,
  `master-clue-reqs` varchar(255) NOT NULL,
  `counters` varchar(255) NOT NULL,
  `max-cape` varchar(255) NOT NULL,
  `zulrah-best-time` varchar(255) NOT NULL,
  `toxic-staff` varchar(255) NOT NULL,
  `toxic-pipe-ammo` varchar(255) NOT NULL,
  `toxic-pipe-amount` varchar(255) NOT NULL,
  `toxic-pipe-charge` varchar(255) NOT NULL,
  `serpentine-helm` varchar(255) NOT NULL,
  `trident-of-the-seas` varchar(255) NOT NULL,
  `trident-of-the-swamp` varchar(255) NOT NULL,
  `arclight-charge` varchar(255) NOT NULL,
  `slayerPoints` varchar(255) NOT NULL,
  `crystal-bow-shots` varchar(255) NOT NULL,
  `skull-timer` varchar(255) NOT NULL,
  `magic-book` varchar(255) NOT NULL,
  `ahrim` varchar(255) NOT NULL,
  `dharok` varchar(255) NOT NULL,
  `guthan` varchar(255) NOT NULL,
  `karil` varchar(255) NOT NULL,
  `torag` varchar(255) NOT NULL,
  `verac` varchar(255) NOT NULL,
  `barrows-final-brother` varchar(255) NOT NULL,
  `barrows-monsters-killcount` varchar(255) NOT NULL,
  `barrows-completed` varchar(255) NOT NULL,
  `special-amount` varchar(225) NOT NULL,
  `prayer-amount` varchar(255) NOT NULL,
  `KC` varchar(255) NOT NULL,
  `DC` varchar(255) NOT NULL,
  `total-hunter-kills` varchar(255) NOT NULL,
  `total-rogue-kills` varchar(255) NOT NULL,
  `target-time-delay` varchar(255) NOT NULL,
  `bh-penalties` varchar(255) NOT NULL,
  `bh-bounties` varchar(255) NOT NULL,
  `statistics-visible` varchar(255) NOT NULL,
  `spell-accessible` varchar(255) NOT NULL,
  `zerkAmount` varchar(255) NOT NULL,
  `pkp` varchar(255) NOT NULL,
  `donP` varchar(255) NOT NULL,
  `donA` varchar(255) NOT NULL,
  `prestige-points` varchar(255) NOT NULL,
  `votePoints` varchar(255) NOT NULL,
  `bloodPoints` varchar(255) NOT NULL,
  `achievement-points` varchar(255) NOT NULL,
  `achievement-items` varchar(255) NOT NULL,
  `xpLock` varchar(255) NOT NULL,
  `teleblock-length` varchar(255) NOT NULL,
  `VarrockClaimedDiaries` varchar(255) NOT NULL,
  `ArdougneClaimedDiaries` varchar(255) NOT NULL,
  `DesertClaimedDiaries` varchar(255) NOT NULL,
  `FaladorClaimedDiaries` varchar(255) NOT NULL,
  `FremennikClaimedDiaries` varchar(255) NOT NULL,
  `KandarinClaimedDiaries` varchar(255) NOT NULL,
  `KaramjaClaimedDiaries` varchar(255) NOT NULL,
  `LumbridgeClaimedDiaries` varchar(255) NOT NULL,
  `MorytaniaClaimedDiaries` varchar(255) NOT NULL,
  `WesternClaimedDiaries` varchar(255) NOT NULL,
  `WildernessClaimedDiaries` varchar(255) NOT NULL,
  `diaries` varchar(255) NOT NULL,
  `partialDiaries` varchar(255) NOT NULL,
  `pc-points` varchar(255) NOT NULL,
  `total-raids` varchar(255) NOT NULL,
  `killStreak` varchar(255) NOT NULL,
  `bonus-end` varchar(255) NOT NULL,
  `jail-end` varchar(255) NOT NULL,
  `mute-end` varchar(255) NOT NULL,
  `marketmute-end` varchar(255) NOT NULL,
  `last-yell` varchar(255) NOT NULL,
  `splitChat` varchar(255) NOT NULL,
  `slayer-master` varchar(255) NOT NULL,
  `consecutive-tasks` varchar(255) NOT NULL,
  `mage-arena-points` varchar(255) NOT NULL,
  `shayzien-assault-points` varchar(255) NOT NULL,
  `autoRet` varchar(255) NOT NULL,
  `flagged` varchar(255) NOT NULL,
  `keepTitle` varchar(255) NOT NULL,
  `killTitle` varchar(255) NOT NULL,
  `wave` varchar(255) NOT NULL,
  `gwkc` varchar(255) NOT NULL,
  `fightMode` varchar(255) NOT NULL,
  `privatechat` varchar(255) NOT NULL,
  `void` varchar(255) NOT NULL,
  `quickprayer` varchar(255) NOT NULL,
  `pouch-rune` varchar(255) NOT NULL,
  `pouch-pure` varchar(255) NOT NULL,
  `crabsKilled` varchar(255) NOT NULL,
  `farming-poison-berry` varchar(255) NOT NULL,
  `herb-patch-1` varchar(255) NOT NULL,
  `herb-patch-2` varchar(255) NOT NULL,
  `herb-patch-3` varchar(255) NOT NULL,
  `herb-patch-4` varchar(255) NOT NULL,
  `herb-patch-5` varchar(255) NOT NULL,
  `herb-patch-6` varchar(255) NOT NULL,
  `herb-patch-7` varchar(255) NOT NULL,
  `compostBin` varchar(255) NOT NULL,
  `halloweenOrderGiven` varchar(255) NOT NULL,
  `halloweenOrderChosen` varchar(255) NOT NULL,
  `halloweenOrderNumber` varchar(255) NOT NULL,
  `district-levels` varchar(255) NOT NULL,
  `inDistrict` varchar(255) NOT NULL,
  `safeBoxSlots` varchar(255) NOT NULL,
  `lost-items` varchar(255) NOT NULL,
  `lost-items-cerberus` varchar(255) NOT NULL,
  `lost-items-skotizo` varchar(255) NOT NULL,
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
CREATE TABLE IF NOT EXISTS `equipment` (
  `username` varchar(50) NOT NULL,
  `character-equip` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hs_users`
--

DROP TABLE IF EXISTS `hs_users`;
CREATE TABLE IF NOT EXISTS `hs_users` (
  `username` varchar(50) NOT NULL,
  `rights` int(2) NOT NULL,
  `mode` int(2) NOT NULL,
  `total_level` int(50) NOT NULL,
  `overall_xp` int(50) NOT NULL,
  `attack_xp` int(50) NOT NULL,
  `defence_xp` int(50) NOT NULL,
  `strength_xp` int(50) NOT NULL,
  `constitution_xp` int(50) NOT NULL,
  `ranged_xp` int(50) NOT NULL,
  `prayer_xp` int(50) NOT NULL,
  `magic_xp` int(50) NOT NULL,
  `cooking_xp` int(50) NOT NULL,
  `woodcutting_xp` int(50) NOT NULL,
  `fletching_xp` int(50) NOT NULL,
  `fishing_xp` int(50) NOT NULL,
  `firemaking_xp` int(50) NOT NULL,
  `crafting_xp` int(50) NOT NULL,
  `smithing_xp` int(50) NOT NULL,
  `mining_xp` int(50) NOT NULL,
  `herblore_xp` int(50) NOT NULL,
  `agility_xp` int(50) NOT NULL,
  `thieving_xp` int(50) NOT NULL,
  `slayer_xp` int(50) NOT NULL,
  `farming_xp` int(50) NOT NULL,
  `runecrafting_xp` int(50) NOT NULL,
  `hunter_xp` int(50) NOT NULL,
  `construction_xp` int(50) NOT NULL,
  `summoning_xp` int(50) NOT NULL,
  `dungeoneering_xp` int(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `online`
--

DROP TABLE IF EXISTS `online`;
CREATE TABLE IF NOT EXISTS `online` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `currentlyonline` int(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` char(32) NOT NULL,
  `email` varchar(50) NOT NULL,
  `rights` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
